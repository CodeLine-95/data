<?php
return [
    'adminEmail' => 'admin@example.com',
    'avatar'     => [
        'small01'  => '/statics/images/avatar/small01.jpg'
    ],
    'default_label_img' => '/statics/images/banner/b_2.jpg',
];
