<?php
/**
 * Created by PhpStorm.
 * User: Joe Handsome
 * Date: 2017/9/29
 * Time: 16:45
 */
namespace frontend\models\base;

/**
 * 公共表单库
 */
use Yii;
use yii\base\Model;

class BaseForm extends Model
{

}