<?php

/* @var $this yii\web\View */

$this->title = '博客系统后台管理系统';
$this->params['breadcrumbs'][] = $this->title;
?>
