<?php
/**
 * Created by PhpStorm.
 * User: Joe Handsome
 * Date: 2017/8/21
 * Time: 15:07
 */
return [
    //导航栏目
    //登录错误信息
    'Incorrect username or password.'             => '用户名或密码错误！',
    'Are you sure you want to delete this item?'  => '您确定要删除此项吗？',
];